#! /bin/sh

./QuantumModelChecker
